package kodlama.io.Week4Odev1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4Odev1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
